<?php

namespace :vendor_namespace;

class :studly_package_name
{
    // Build your next great package.
}
