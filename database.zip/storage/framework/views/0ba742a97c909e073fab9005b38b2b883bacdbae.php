<div class="pt-24 w-full md:w-11/12 mx-auto">
    <form wire:submit.prevent="submit">
        <fieldset class="mt-6">
            <legend class="mb-4 text-3xl leading-6 font-medium text-dark-blue-800">
                Which <span class="text-hulk-800">package</span> do you want to build?
            </legend>
            <p class="text leading-6 text-gray-700">
                The package boilerplates come with pre-configured
                continuous
                integration services out of the box.
                With GitHub Actions and StyleCI you can rely on powerful tools for your software
                quality,
                automated tests and code styling.</p>
            <div x-data="{packageType: 'laravel'}"
                 class="mt-8 flex items-center flex-col md:flex-row w-full justify-center">
                <div class="flex flex-col items-center md:mr-16">
                    <button type="button" @click="packageType = 'laravel'" wire:click="setPackageType('laravel')"
                            class="ml-3 bg-white py-8 px-24 flex items-center justify-center shadow  border-2 transition duration-150 h-36 md:h-auto"
                            :class="{ 
                                'border-hulk-800': packageType === 'laravel',
                                'border-transparent hover:border-hulk-100': packageType !== 'laravel'
                            }">
                        <svg xmlns="http://www.w3.org/2000/svg" class="w-24 md:h-12 md:w-auto" viewBox="0 0 50 52">
                            <path
                                d="M49.626 11.564a.809.809 0 0 1 .028.209v10.972a.8.8 0 0 1-.402.694l-9.209 5.302V39.25c0 .286-.152.55-.4.694L20.42 51.01c-.044.025-.092.041-.14.058-.018.006-.035.017-.054.022a.805.805 0 0 1-.41 0c-.022-.006-.042-.018-.063-.026-.044-.016-.09-.03-.132-.054L.402 39.944A.801.801 0 0 1 0 39.25V6.334c0-.072.01-.142.028-.21.006-.023.02-.044.028-.067.015-.042.029-.085.051-.124.015-.026.037-.047.055-.071.023-.032.044-.065.071-.093.023-.023.053-.04.079-.06.029-.024.055-.05.088-.069h.001l9.61-5.533a.802.802 0 0 1 .8 0l9.61 5.533h.002c.032.02.059.045.088.068.026.02.055.038.078.06.028.029.048.062.072.094.017.024.04.045.054.071.023.04.036.082.052.124.008.023.022.044.028.068a.809.809 0 0 1 .028.209v20.559l8.008-4.611v-10.51c0-.07.01-.141.028-.208.007-.024.02-.045.028-.068.016-.042.03-.085.052-.124.015-.026.037-.047.054-.071.024-.032.044-.065.072-.093.023-.023.052-.04.078-.06.03-.024.056-.05.088-.069h.001l9.611-5.533a.801.801 0 0 1 .8 0l9.61 5.533c.034.02.06.045.09.068.025.02.054.038.077.06.028.029.048.062.072.094.018.024.04.045.054.071.023.039.036.082.052.124.009.023.022.044.028.068zm-1.574 10.718v-9.124l-3.363 1.936-4.646 2.675v9.124l8.01-4.611zm-9.61 16.505v-9.13l-4.57 2.61-13.05 7.448v9.216l17.62-10.144zM1.602 7.719v31.068L19.22 48.93v-9.214l-9.204-5.209-.003-.002-.004-.002c-.031-.018-.057-.044-.086-.066-.025-.02-.054-.036-.076-.058l-.002-.003c-.026-.025-.044-.056-.066-.084-.02-.027-.044-.05-.06-.078l-.001-.003c-.018-.03-.029-.066-.042-.1-.013-.03-.03-.058-.038-.09v-.001c-.01-.038-.012-.078-.016-.117-.004-.03-.012-.06-.012-.09v-.002-21.481L4.965 9.654 1.602 7.72zm8.81-5.994L2.405 6.334l8.005 4.609 8.006-4.61-8.006-4.608zm4.164 28.764l4.645-2.674V7.719l-3.363 1.936-4.646 2.675v20.096l3.364-1.937zM39.243 7.164l-8.006 4.609 8.006 4.609 8.005-4.61-8.005-4.608zm-.801 10.605l-4.646-2.675-3.363-1.936v9.124l4.645 2.674 3.364 1.937v-9.124zM20.02 38.33l11.743-6.704 5.87-3.35-8-4.606-9.211 5.303-8.395 4.833 7.993 4.524z"
                                fill="#FF2D20" fill-rule="evenodd"/>
                        </svg>
                    </button>
                    <a class="mt-4" target="_blank" class="text-dark-blue-800" href="https://github.com/beyondcode/skeleton-laravel">See on GitHub</a>
                </div>
                <div class="flex items-center flex-col mt-4 md:mt-0">
                    <button type="button" @click="packageType = 'php'" wire:click="setPackageType('php')"
                            class="ml-3 bg-white py-8 px-24 shadow border-2 transition duration-150 h-36 md:h-auto"
                            :class="{
                            'border-hulk-800': packageType === 'php',
                            'border-transparent hover:border-hulk-100': packageType !== 'php'
                        }">
                        <svg xmlns="http://www.w3.org/2000/svg" class="w-24 md:h-12 md:w-auto" viewBox="0 -1 100 50">
                            <path
                                d="m7.579 10.123 14.204 0c4.169 0.035 7.19 1.237 9.063 3.604 1.873 2.367 2.491 5.6 1.855 9.699-0.247 1.873-0.795 3.71-1.643 5.512-0.813 1.802-1.943 3.427-3.392 4.876-1.767 1.837-3.657 3.003-5.671 3.498-2.014 0.495-4.099 0.742-6.254 0.742l-6.36 0-2.014 10.07-7.367 0 7.579-38.001 0 0m6.201 6.042-3.18 15.9c0.212 0.035 0.424 0.053 0.636 0.053 0.247 0 0.495 0 0.742 0 3.392 0.035 6.219-0.3 8.48-1.007 2.261-0.742 3.781-3.321 4.558-7.738 0.636-3.71 0-5.848-1.908-6.413-1.873-0.565-4.222-0.83-7.049-0.795-0.424 0.035-0.83 0.053-1.219 0.053-0.353 0-0.724 0-1.113 0l0.053-0.053"/>
                            <path
                                d="m41.093 0 7.314 0-2.067 10.123 6.572 0c3.604 0.071 6.289 0.813 8.056 2.226 1.802 1.413 2.332 4.099 1.59 8.056l-3.551 17.649-7.42 0 3.392-16.854c0.353-1.767 0.247-3.021-0.318-3.763-0.565-0.742-1.784-1.113-3.657-1.113l-5.883-0.053-4.346 21.783-7.314 0 7.632-38.054 0 0"/>
                            <path
                                d="m70.412 10.123 14.204 0c4.169 0.035 7.19 1.237 9.063 3.604 1.873 2.367 2.491 5.6 1.855 9.699-0.247 1.873-0.795 3.71-1.643 5.512-0.813 1.802-1.943 3.427-3.392 4.876-1.767 1.837-3.657 3.003-5.671 3.498-2.014 0.495-4.099 0.742-6.254 0.742l-6.36 0-2.014 10.07-7.367 0 7.579-38.001 0 0m6.201 6.042-3.18 15.9c0.212 0.035 0.424 0.053 0.636 0.053 0.247 0 0.495 0 0.742 0 3.392 0.035 6.219-0.3 8.48-1.007 2.261-0.742 3.781-3.321 4.558-7.738 0.636-3.71 0-5.848-1.908-6.413-1.873-0.565-4.222-0.83-7.049-0.795-0.424 0.035-0.83 0.053-1.219 0.053-0.353 0-0.724 0-1.113 0l0.053-0.053"/>
                        </svg>
                    </button>
                    <a class="mt-4" target="_blank" class="text-dark-blue-800" href="https://github.com/beyondcode/skeleton-php">See on GitHub</a>
                </div>
            </div>
        </fieldset>
        <fieldset class="mt-12">
            <legend class="mb-4 text-3xl leading-6 font-medium text-dark-blue-800">
                Fill in some package <span class="text-hulk-800">details</span>
            </legend>
            
            
            
            
            
            
            
            
            
            
            
            
            
            <div class="grid grid-cols-6 gap-6">

                <div class="col-span-6 sm:col-span-3">
                    <label wire:target="vendorName" for="vendorName"
                           class="block text-sm font-medium leading-5 text-gray-700">Vendor
                        Name</label>
                    <input wire:model="vendorName"
                           id="vendorName"
                           placeholder="beyondcode"
                           class="mt-1 border form-input block w-full transition duration-150 ease-in-out sm:text-sm sm:leading-5">
                    <?php $__errorArgs = ['vendorName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-sm text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>

                <div class="col-span-6 sm:col-span-3">
                    <label wire:target="packageName" for="packageName"
                           class="block text-sm font-medium leading-5 text-gray-700">
                        Package Name
                    </label>
                    <input wire:model="packageName"
                           id="packageName"
                           placeholder="my-package"
                           class="mt-1  border form-input block w-full transition duration-150 ease-in-out sm:text-sm sm:leading-5">
                    <?php $__errorArgs = ['packageName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-sm text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>

                <div class="col-span-6 sm:col-span-3">
                    <label wire:target="authorName" for="authorName"
                           class="block text-sm font-medium leading-5 text-gray-700">
                        Author Name
                    </label>
                    <input wire:model="authorName"
                           id="authorName"
                           placeholder="Jane Doe"
                           class="mt-1 border form-input block w-full transition duration-150 ease-in-out sm:text-sm sm:leading-5">
                    <?php $__errorArgs = ['authorName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-sm text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>

                <div class="col-span-6 sm:col-span-3">
                    <label wire:target="authorEmail" for="authorEmail"
                           class="block text-sm font-medium leading-5 text-gray-700">
                        Author E-Mail
                    </label>
                    <input wire:model="authorEmail"
                           id="authorEmail"
                           placeholder="author@domain.com"
                           class="mt-1 border  form-input block w-full transition duration-150 ease-in-out sm:text-sm sm:leading-5">
                    <?php $__errorArgs = ['authorEmail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-sm text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>

                <div class="col-span-6">
                    <label wire:target="packageDescription" for="packageDescription"
                           class="block text-sm font-medium leading-5 text-gray-700">
                        Package Description
                    </label>
                    <input wire:model="packageDescription"
                           id="packageDescription"
                           placeholder="My awesome package"
                           class="mt-1  border form-input block w-full transition duration-150 ease-in-out sm:text-sm sm:leading-5">
                    <?php $__errorArgs = ['packageDescription'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-sm text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>


                <div class="col-span-6 ">
                    <div class=" flex items-center">
                        <label wire:target="license"
                               for="license"
                               class="block text-sm font-medium leading-5 text-gray-700">
                            License
                        </label>
                        <a href="https://choosealicense.com/"
                           class="text-gray-500 transition duration-300 hover:text-hulk-800" target="_blank">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 ml-2" viewBox="0 0 20 20"
                                 fill="currentColor">
                                <path fill-rule="evenodd"
                                      d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z"
                                      clip-rule="evenodd"/>
                            </svg>
                        </a>
                    </div>
                    <select wire:model="license"
                            id="license"
                            class="mt-1 block form-select w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:shadow-outline-blue focus:border-blue-300 transition duration-150 ease-in-out sm:text-sm sm:leading-5">
                        <option value="mit">MIT License</option>
                        <option value="agpl-3">GNU AGPLv3</option>
                        <option value="gpl-3">GNU GPLv3</option>
                        <option value="lgpl-3">GNU LGPLv3</option>
                        <option value="mozilla-public-2">Mozilla Public License 2.0</option>
                        <option value="apache-2">Apache License 2.0</option>
                        <option value="unlicense">The Unlicense</option>
                    </select>
                </div>


                <div class="col-span-6">
                    <div class="mt-4">
                        <div class="relative flex items-start">
                            <div class="flex items-center h-5">
                                <input wire:model="newsletter" id="newsletter" type="checkbox"
                                       class="form-checkbox h-4 w-4 text-hulk-600 transition duration-150 ease-in-out">
                            </div>
                            <div class="ml-4 leading-5 ">
                                <label wire:target="newsletter" for="newsletter"
                                       class="font-semibold text-dark-blue-800 mr-3">Stay in the <span
                                        class="text-hulk-800">loop</span></label>
                                <p class="text-dark-blue-800">I want to stay informed about upcoming Beyond Code
                                    products and courses</p>
                            </div>
                        </div>
                    </div>
                </div>


            </div>
        </fieldset>
        <fieldset class="mt-12">
            <legend class="mb-4 text-3xl leading-6 font-medium text-dark-blue-800">
                You're almost <span class="text-hulk-800">done!</span>
            </legend>
            <div class=" pb-8 text leading-5 text-gray-700">
                
                Download the ZIP file and you're good to go!

                <div class="flex mx-auto mt-8 justify-center items-center ">
                    
                    
                    
                    
                    
                    
                    
                    
                    <button
                        class="ml-3 font-semibold flex flex-col items-center justify-center tracking-wide text-white hover:bg-hulk-700 bg-hulk-800  py-8 px-12 hover:border-hulk-100 shadow border-transparent transition duration-150 hover:border-hulk-800 border-2">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-12 w-12 mb-4" fill="none" viewBox="0 0 24 24"
                             stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                  d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/>
                        </svg>

                        Download my package
                    </button>
                </div>
            </div>
        </fieldset>

    </form>
</div>
<?php /**PATH D:\Users\Documents\GitHub\laravelpackageboilerplate.com\resources\views/livewire/boilerplate-form.blade.php ENDPATH**/ ?>