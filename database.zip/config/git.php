<?php

return [

    'executable' => env('GIT_EXECUTABLE')

];