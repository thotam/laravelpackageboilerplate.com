<?php return array (
  'boilerplate-form' => 'App\\Http\\Livewire\\BoilerplateForm',
);