# Laravel Package Boilerplate

This repository contains the code for [Laravel Package Boilerplate](https://www.laravelpackageboilerplate.com) - a website where you can generate your next PHP/Laravel package code.

### Security

If you discover any security related issues, please email marcel@beyondco.de instead of using the issue tracker.

## Credits

- [Marcel Pociot](https://github.com/mpociot)
- [All Contributors](../../contributors)

## License

The MIT License (MIT). Please see [License File](LICENSE.md) for more information.